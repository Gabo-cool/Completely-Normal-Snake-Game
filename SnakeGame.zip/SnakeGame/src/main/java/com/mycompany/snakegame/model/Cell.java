package com.mycompany.snakegame.model;

/**
 * One square of the board, addressed by column and row (not pixels).
 *
 * MODULE 5 PROOF (Modern Java): a record is a compact immutable data carrier.
 * Records give us equals()/hashCode() for free, which is what makes Cell usable
 * inside a HashSet (MODULE 6).
 */
public record Cell(int col, int row) {

    /** MODULE 3 PROOF: a method that returns a new object instead of mutating this one. */
    public Cell step(Direction direction) {
        return new Cell(col + direction.dx(), row + direction.dy());
    }
}
